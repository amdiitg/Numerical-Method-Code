#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double func(double t)
{
    return (2 - 2 * t + 4 * pow(t, 2) - 4 * pow(t, 3) - 4 * pow(t, 4));
}

int main()
{
    ofstream out;
    out.open("output_adoms.txt");
    double t[50], y[50], t0, y0, tmax, k, k1, k2, k3, k4, l, l1, l2, l3, l4;
    int i, j, n;
    t0 = 0, y0 = 1, tmax = 1;
    double h[3] = {0.1, 0.05, 0.025};
    for (j = 0; j < 3; j++)
    {
        out << "solution when step size is: " << h[j] << endl;
        n = (tmax - t0) / h[j];
        y[0] = y0, t[0] = t0;

        // applying runge kutta 4rth order to find first three guess
        for (i = 0; i < 3; i++)
        {
            k1 = h[j] * func(t[i]);
            k2 = h[j] * func(t[i] + h[j] / 2);
            k3 = h[j] * func(t[i] + h[j] / 2);
            k4 = h[j] * func(t[i] + h[j]);
            k = (k1 + 2 * k2 + 2 * k3 + k4) / 6;
            y[i + 1] = y[i] + k;
            t[i + 1] = t[i] + h[j];
        }

        // now applying adoms bashforth for further calculation

        for (i = 3; i < n; i++)
        {
            y[i + 1] = y[i] + (h[j] / 24) * (55 * func(t[i]) - 59 * func(t[i - 1]) + 37 * func(t[i - 2]) - 9 * func(t[i - 3]));
            t[i + 1] = t[i] + h[j];
        }

        for (i = 0; i <= n; i++)
        {
            out << t[i] << '\t' << y[i] << endl;
        }
    }
    out.close();
    cout << "output has printed in 'output_adoms' file:" << endl;
    return 0;
}