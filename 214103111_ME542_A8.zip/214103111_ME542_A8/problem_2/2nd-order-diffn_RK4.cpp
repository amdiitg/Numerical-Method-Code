#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double funczp(double t, double y, double z)
{
    return (2 * t * t * t + 2 * y - 4 * z - 10);
}

double funcyp(double z)
{
    return z;
}

int main()
{
    ofstream out;
    out.open("output_2nd-ques.txt");
    double t, y, t0, y0, z, z0, tmax, k, k1, k2, k3, k4, l, l1, l2, l3, l4;
    double h[3] = {0.1, 0.05,0.025};
    int i, j, n;
    t0 = 0, y0 = 0, z0 = 1, tmax = 1;

    for (j = 0; j < 3; j++)
    {
        out << "solution by RK4 if step size h is:" << h[j] << endl;
        n = (tmax - t0) / h[j];
        t = t0;
        y = y0;
        z = z0;
        out<<t<<'\t'<<y<<endl;
        for (i = 0; i < n; i++)
        {
            l1 = h[j] * funcyp(z);
            k1 = h[j] * funczp(t, y, z);
            l2 = h[j] * funcyp(z + l1 / 2);
            k2 = h[j] * funczp(t + h[j] / 2, y + k1 / 2, z + l1 / 2);
            l3 = h[j] * funcyp(z + l2 / 2);
            k3 = h[j] * funczp(t + h[j] / 2, y + k2 / 2, z + l2 / 2);
            l4 = h[j] * funcyp(z + l3);
            k4 = h[j] * funczp(t + h[j], y + k3, z + l3);
            k = (k1 + 2 * k2 + 2 * k3 + k4) / 6;
            l = (l1 + 2 * l2 + 2 * l3 + l4) / 6;
            z = z + k;
            y = y + l;
            t = t + h[j];
            out << t << '\t' << y << endl;
        }
        out << endl;
    }
    out.close();

    cout << "solution is printed in 'output_2nd-ques'file" << endl;
    return 0;
}