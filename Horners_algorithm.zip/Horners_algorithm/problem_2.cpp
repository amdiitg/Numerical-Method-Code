#include <iostream>
using namespace std;

float fact(int n)
{
    float y = n;
    for (int i = n - 1; i > 0; i--)
    {
        y = y * i;
    }
    return y;
}

int main()
{
    int n, j = 1;
    cout << "Enter the no of terms:" << endl;
    cin >> n;
    float a[n], an;
    // finding coefficient of sinx in taylor series upto given n terms //
    for (int i = 1; i <= n; i++)
    {

        if (i % 2 == 0)
            a[i] = 0;
        else
        {
            if (j % 2 == 0)
                a[i] = (-1) / fact(i);
            else
                a[i] = (1) / fact(i);
            j++;
        }
        an = a[i];
        cout << a[i] << endl;
    }

    // applying Horner's algorithm to find value of sinx at given value of x in degree://
int arithno,count ;
float pi=3.1415;
float bnminus1,b[n-1],r,pr,x;
cout<<"enter the value of x in degree:"<<endl;
cin>>x;
r=((pi/180)*x);
bnminus1=an;
for(int i=n-1;i>0;i--)
{
    b[i-1]=a[i]+r*b[i];
    pr=b[i-1];
 
}
arithno=2*(n-1);    
cout<<"No of arithmatic operation by Horner's method is: "<<arithno<<endl;
cout<<" the value of sinx at above given angle using Horner's is:  "<<pr<<endl; 

    return 0;
}