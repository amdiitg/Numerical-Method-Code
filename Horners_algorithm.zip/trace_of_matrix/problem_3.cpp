#include<iostream>
#include<cmath>

using namespace std;
int main()
{
    
    
    int a[10][10];
    int trace=0;
    cout<<"Enter all the elements:"<<endl;
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<10;j++)
        {
            
            a[i][j]=rand()%101;
        }
    }
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<10;j++)
        {
            cout<<a[i][j]<<" ";
            if(i==j)
            {
                trace=trace+a[i][j];
            }
        }
        cout<<endl;
    }
    cout<<" trace of the matrix is : "<<trace;
    return 0;
}