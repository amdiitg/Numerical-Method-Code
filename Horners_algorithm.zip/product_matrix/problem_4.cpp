#include<iostream>
using namespace std;

int main()
{
    int i,j,k,sum=0;
    int a[20][20],b[20][20],c[20][20];
    int arow,acol,brow,bcol;
    cout<<"Enter the size of  row and column of a matrix"<<endl;
    cin>>arow;

    cin>>acol;
    cout<<" Enter the elements of a matrix"<<endl;

    for(i=0;i<arow;i++)
    {
        for(j=0;j<acol;j++)
        {
            cin>> a[i][j];
        }
    }

    cout<<"Enter the size of  row and column of b matrix"<<endl;
    
    cin>>brow;
    cin>>bcol;
    if(acol!=brow)
    {
        cout<<"sorry we can't multiply this:";
        exit(0);
    }
    else
    {
    cout<<"enter the element of matrix b:"<<endl;
    for(i=0;i<brow;i++)
    {
        for(j=0;j<bcol;j++)
        {
         cin>>b[i][j];
        }
    }
    }
    cout<<"The product of matrix and vector is given below:"<<endl;
    for(int k=0;k<bcol;k++)
    {
       for(i=0;i<arow;i++)
      {
        for(j=0;j<brow;j++)
        {
         
         
             sum=sum+a[i][j]*b[j][k];
            
        
        }
        cout<<sum<<endl;
        sum=0;
      }
    }
    return 0;
}
