#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;



//function to find coefficient of every term//


double func(double x1, int n)
{

    double y = 1;
    for (int i = n; i > 0; i--)
    {
        y = (y * x1) / n;
        n--;
    }
    return y;
}

int main()
{

    ofstream out;
    out.open("dataplot.dat");
    double sum, term, x, pi, degree, error, lastsum;
    pi = 3.1415;
    cout << "Enter the value of  x  in degree:  ";
    cin >> degree;
    x = (degree * pi) / 180;

    sum = 0;
    int sign = 1,count;
    int j = 1;
    cout << "no of count and relative error is in dat file:" << endl;
    cout << "for example i have taken here 45 degree for plotting , you can check for any value: " << endl;

    do
    {

        if (sign % 2 == 0)
            term = (-1) * func(x, j);
        else
            term = func(x, j);

        sum = sum + term;

        error = abs((sin(x) - sum) / sin(x));
        out << sign << " " << abs(error) << endl;

        sign++;
        j = j + 2;
count =j;
    } while (error > 0);
    cout << endl;
    cout << "the value of sinx is: " << sum << endl;

    
    return 0;
}