#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>
using namespace std;

int main()
{

    ifstream in;
    ofstream out;
    int n = 5;
    float a[n][n], b[n], x[n], r[n], d[n]; // n is no of unknown
    in.open("input_A_mat.txt");
    for (int i = 0; i < n; i++) // input for coefficinent matrix from file
    {
        for (int j = 0; j < n; j++)
        {
            in >> a[i][j];
        }
    }
    in.close();
    in.open("input_b_vect.txt");
    for (int i = 0; i < n; i++) // input for b vector from file
    {
        in >> b[i];
    }
    in.close();
    for (int i = 0; i < n; i++) // intial guess for x
    {
        x[i] = 0;
    }

    for (int i = 0; i < n; i++)
    {
        float sum = 0;
        for (int j = 0; j < n; j++)
        {
            sum = sum + a[i][j] * x[j];
        }
        d[i] = r[i] = b[i] - sum;
    }
    int k = 1;
    float del = 0.1, l, m, p, q, s, t; // in place of alpha and beta i have taken l amd m which is in standard algorithm

    // conjugate gradient method//

    // step1//
    out.open("output_by_method(b).txt");
    out << "itr      x(1)         x(2)           x(3)          x(4)           x(5)            del" << endl;
    while (k < 50 && del > 0.000001)
    {
        p = 0;
        for (int i = 0; i < n; i++)
        {
            p = p + r[i] * r[i];
        }
        q = 0;
        for (int i = 0; i < n; i++)
        {
            float sum = 0;
            for (int j = 0; j < n; j++)
            {
                sum = sum + a[i][j] * d[j];
            }
            q = q + d[i] * sum;
        }
        l = p / q;
        // step2//

        for (int i = 0; i < n; i++)
        {
            x[i] = x[i] + l * d[i];
        }

        t = 0;
        for (int i = 0; i < n; i++)
        {
            t = t + r[i] * r[i];
        }

        // step3//
        for (int i = 0; i < n; i++)
        {
            float sum = 0;
            for (int j = 0; j < n; j++)
            {
                sum = sum + a[i][j] * d[j];
            }
            r[i] = r[i] - l * sum;
        }
        // step4//
        s = 0;
        for (int i = 0; i < n; i++)
        {
            s = s + r[i] * r[i];
        }

        m = s / t;
        // step5//
        for (int i = 0; i < n; i++)
        {
            d[i] = r[i] + m * d[i];
        }

        del = 0;
        for (int i = 0; i < n; i++)
        {
            del = del + r[i] * r[i];
        }

        del = sqrt(del);

        out << k << "        ";
        for (int i = 0; i < n; i++)
        {
            out << x[i] << "           ";
        }
        out << del << endl;
        k++;
    }

    out.close();
    return 0;
}