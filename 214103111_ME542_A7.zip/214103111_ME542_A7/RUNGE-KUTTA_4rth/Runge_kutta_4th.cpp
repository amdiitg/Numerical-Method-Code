#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double ypfunc(double x) // dy/dx
{
    return (-2 *pow(x,3) + 12 *pow(x,2) - 20 * x + 8.5);
}
int main()
{
    ofstream out;
    out.open("output_RK4.txt");
    double x,y,x0,y0,xmax,k,k1,k2,k3,k4;
    double h[3]={0.5,0.25,0.1};
    int i,j,n;
    x0=0,y0=1,xmax=4;


    for ( j = 0; j < 3; j++)
    {
        out<<"solution by RK4 if step size h is:"<<h[j]<<endl;
        n=(xmax-x0)/h[j];
        x=x0;
        y=y0;
        for ( i = 0; i < n; i++)
        {
            k1=h[j]*ypfunc(x);
            k2=h[j]*ypfunc(x+(h[j]/2));
            k3=h[j]*ypfunc(x+(h[j]/2));
            k4=h[j]*ypfunc(x+h[j]);
            k=(k1+2*k2+2*k3+k4)/6;
            y=y+k;
            x=x+h[j];
            out<<x<<'\t'<<y<<endl;
        }
        out<<endl;
        
    }
    out.close();
    
cout<<"solution is printed in 'output_RK4'file"<<endl;
    return 0;
}