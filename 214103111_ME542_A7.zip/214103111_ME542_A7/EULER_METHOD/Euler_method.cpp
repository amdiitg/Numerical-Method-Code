#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double yp(double x)
{
    return (-2 * x * x * x + 12 * x * x - 20 * x + 8.5);
}
double ytrue(double x)
{
    return (-0.5*pow(x,4)+4*pow(x,3)-10*x*x+8.5*x+1);
}
int main()
{
    ofstream out;
    out.open("output_euler.txt");
    double x0, y0, x, y, xmax = 4,ya,xa;
    double h[3] = {0.5,0.25,0.1};
    x0 = 0, y0 = 1;
    int n;
    for (int j = 0; j < 3; j++)
    {
        out<<"output by euler method when step size h is:"<<h[j]<<endl;
        x = x0;
        y = y0;
        
        n = (xmax - x0)/h[j];
        for(int i = 0; i< n; i++)
        {
            y= y + h[j] * yp(x);
            x = x + h[j];
            out << x << '\t' << y << endl;
        }
        out<<"solution by analytical when step size is:"<<h[j]<<endl;
        xa=x0;
        for (int i = 0; i <=n; i++)
        {
            ya=ytrue(xa);
            out<<xa<<'\t'<<ya<<endl;
            xa=xa+h[j];
        }

        
    }
    out.close();
    cout<<"solution is printed in 'output_euler'file"<<endl;
    return 0;
}

