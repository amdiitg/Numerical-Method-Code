
// solving the question nimber 2 by secant method

#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double f(double x) // defining the function
{
    double y = x * exp(x) - 1;
    return y;
}

int main()
{
    ofstream out;
    out.open("secant_conv_data.txt");
    int i = 0;
    double error[100];
    int itr[100];
    double a, b, x, fa, fb, fx, e;
    cout << " Enter the range of the zeros a and b:" << endl;
    cin >> a >> b;

    do
    {
        fa = f(a);
        fb = f(b);
        x = (((a * fb) - (b * fa)) / (fb - fa));
        fx = f(x);
        e=x-b;
        b = x;
        fb = fx;
        i++;
        error[i] = e;
        itr[i] = i;

    } while (abs(fx) > pow(10, -6));

    cout << " zeros of the function by false position method is:" << x << endl;
    cout << "number of iteration is :" << i;
    for (int j = 1; j <= i; j++)
    {
        out << itr[j] << " ";
    }
    out << endl;
    for (int j = 1; j <= i; j++)
    {
        out << abs(error[j]) << " ";
    }
    return 0;
}