#include <iostream>
#include <cmath>
#include<fstream>
using namespace std;

double f(double x) // defining the function
{
    double y = x * exp(x) - 1;
    return y;
}

double fp(double x) // defining fp as a differentiable function of f
{
    double y = exp(x) * (x + 1);
    return y;
}
int main()
{
ofstream out;
    out.open("convergence_data.txt");
    int i = 0;
    double x0, x1, fx0, fx1, fpx0, e;
    cout << "Enter the initial guess value:";
    cin >> x0;
    float error[100];
    int itr[100];

    do
    {
        fx0 = f(x0);
        fpx0 = fp(x0);
        x1 = (x0 - (fx0 / fpx0));
        e = x1 - x0;

        fx1 = f(x1);
        x0 = x1;
        i++;
        error[i] = e;
        itr[i] = i;

    } while (abs(e) > pow(10, -6));

    cout << "root of the function by newton method is   :" << x1 << endl;
    cout << "And the number of iteration to find root is:" << i << endl;
    cout << "Error is" << endl;
    for(int j=1;j<=i;j++)
    {
        out<<itr[j]<<" ";
    }
    out<<endl;
    for(int j=1;j<=i;j++)
    {
        out<<abs(error[j])<<" ";
    }
    return 0;
}