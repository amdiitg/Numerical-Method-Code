#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double f(double x)
{
    double y = (x * x - x - 2);
    return y;
}

int main()
{
    int i = 0;
    ofstream file("rate of convergence data", out);
    double a, b, x, fa, fb, fx, e;
    cout << " Enter the range of the zeros a and b:" << endl;
    cin >> a >> b;

    do
    {
        fa = f(a);
        fb = f(b);
        e = a - b;
        x = (((a * fb) - (b * fa)) / (fb - fa));
        fx = f(x);
        if ((fa * fx) < 0)
        {
            b = x;
            fb = fx;
            fa = fa / 2;
        }
        else
        {
            a = x;
            fa = fx;
            fb = fb / 2;
        }
        i++;

    } while (abs(fx) > pow(10, -6));

    cout << " zeros of the function by false position method is:" << x;
    return 0;
}