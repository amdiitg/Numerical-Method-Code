#include <iostream>
#include<cmath>

using namespace std;
double xiupper(double t,double h)
{
return ((1/pow(h,2))-(cos(t)/(2*h)));
}

double xi(double t,double h)
{
return ((-2/pow(h,2))-sin(t));
}

double xilower(double t,double h)
{
return ((1/pow(h,2))+(cos(t)/(2*h)));
}
double coeff(double t)
{
return -exp(t);
}
int main()
{
   
int i,j,k,p;
    int n[2]={10,100};
    for(p=0;p<=1;p++)
    {
	cout<<"solution is when n="<<n[p]<<endl;
    n[p]=n[p]-1;
    double t0,tmax,h,a[n[p]][n[p]]={0},b[n[p]],t[i],l[n[p]][n[p]],u[n[p]][n[p]],x[n[p]],y[n[p]],c,sum;
    t0=0,tmax=1;
    h=(tmax-t0)/n[p];
    t[0]=t0;


    for(i=0;i<n[p];i++)
    {
        t[i+1]=t[i]+h;
   
    for(j=0;j<n[p];j++)
    {
    if(i==j)
    a[i][j]=xi(t[i+1],h);
    else if(i-j==1)
    a[i][j]=xilower(t[i+1],h);
    else if(j-i==1)
    a[i][j]=xiupper(t[i+1],h);
    }
    if(i==0)
    b[i]=coeff(t[i+1])-xilower(t[i+1],h);
    else
    if(i<n[p]-1 && i>0)
    b[i]=coeff(t[i+1]);
    else
    b[i]=coeff(t[i+1])-xiupper(t[i+1],h);
   // cout<<b[i]<<endl;
    }



   /* for(i=0;i<n[p];i++)
    {
    for(j=0;j<n[p];j++)
    {
     cout<<a[i][j]<<"  ";
    }
    cout<<endl;
    }*/
    
    
    for (i = 0; i < n[p]; i++)
    {
        for (j = 0; j < n[p]; j++)
        {
            if (i == j)
                l[i][j] = 1;
            else
                l[i][j] = 0;
        }
    }

    for (k = 0; k < n[p] - 1; k++)
    {
        for (i = k + 1; i < n[p]; i++)
        {
            c = a[i][k] / a[k][k];
            l[i][k] = c;
            for (j = 0; j < n[p]; j++)
            {
                a[i][j] = a[i][j] - c * a[k][j];
            }
        }
    }
    for (i = 0; i < n[p]; i++)
    {
        for (j = 0; j < n[p]; j++)
        {
            u[i][j] = a[i][j];
        }
    }
    
    // now solve Ly=b and the Ux=y to find x
        // first solve Ly=b by forward substitution//

        y[0] = b[0];
        for (i = 1; i < n[p]; i++)
        {
            sum = 0;
            for (j = 0; j < i; j++)
            {
                sum = sum + l[i][j] * y[j];
            }
            y[i] = b[i] - sum;
        }

        // now solve Ux=y by backward substitution//
        x[n[p] - 1] = y[n[p] - 1] / u[n[p] - 1][n[p] - 1];
        for (i = n[p] - 2; i >= 0; i--)
        {
            sum = 0;
            for (j = i + 1; j < n[p]; j++)
            {
                sum = sum + u[i][j] * x[j];
            }
            x[i] = (y[i] - sum) / u[i][i];
        }

for(i=0;i<n[p];i++)
{
	cout<<x[i]<<endl;
}
cout<<endl;
}
    return 0;
}
