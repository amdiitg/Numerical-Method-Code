#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

int main()
{
    ifstream in;
    ofstream out;
    int n = 50, i, j, k, p;
    float a[n][n], l[n][n], u[n][n], c, sum, y[n], b[n][n], x[n];
    // input to the coefficient a matrix
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (j == i)
                a[i][j] = 5;
            else if (j == i + 1)
                a[i][j] = -1;
            else if (j == i - 1)
                a[i][j] = -1;
            else
                a[i][j] = 0;
        }
    }
    // printing input a matrix in file
    out.open("a_printed.txt");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            out << a[i][j] << " ";
        }
        out << endl;
    }
    out.close();

    // input to the b matrix column wise
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i + j < n)
                b[i][j] = i + j + 1;
            else
                b[i][j] = abs(i + j - n + 1);
        }
    }

    // printing b matrix in file
    out.open("b_printed.txt");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            out << b[i][j] << " ";
        }
        out << endl;
    }
    out.close();

    // Finding LU(doolittle) for solve to solve the equation
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j)
                l[i][j] = 1;
            else
                l[i][j] = 0;
        }
    }

    for (k = 0; k < n - 1; k++)
    {
        for (i = k + 1; i < n; i++)
        {
            c = a[i][k] / a[k][k];
            l[i][k] = c;
            for (j = 0; j < n; j++)
            {
                a[i][j] = a[i][j] - c * a[k][j];
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            u[i][j] = a[i][j];
        }
    }

    cout << "solution is printed in the solution_output file:" << endl;
    cout << "input a and b matrix is also printed in a_printed and b_printed file " << endl;
    out.open("solution_output.txt");
    for (k = 0; k < n; k++)
    {
        // solving Ly=b by forward
        y[0] = b[0][k];
        for (i = 1; i < n; i++)
        {
            sum = 0;
            for (j = 0; j < i; j++)
            {
                sum = sum + l[i][j] * y[j];
            }
            y[i] = b[i][k] - sum;
        }

        // now solve Ux=y by backward substitution//
        x[n - 1] = y[n - 1] / u[n - 1][n - 1];
        for (i = n - 2; i >= 0; i--)
        {
            sum = 0;
            for (j = i + 1; j < n; j++)
            {
                sum = sum + u[i][j] * x[j];
            }
            x[i] = (y[i] - sum) / u[i][i];
        }
        out <<"solution is by giving input b["<<k+1<<"] column wise :" << endl;
        for (i = 0; i < n; i++)
        {
            out << x[i] << " ";
        }
        out << endl
            << endl;
    }
    out.close();
    return 0;
}