#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;


int main()
{
    int k;
double a[100][100], b[100], x[100], r[100], del;
    ifstream in;
    ofstream out;
    in.open("newdata.txt");
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < 100; j++)
        {
            in >> a[i][j];
        }
    }
    in.close();
    out.open("matrix_a.txt");
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < 100; j++)
        {
            out << a[i][j] << " ";
        }
        out << endl;
    }
    out.close();

    in.open("newb.txt");
    for (int i = 0; i < 100; i++)
    {
        in >> b[i];
    }
    in.close();

    out.open("matrix_b.txt");
    for (int i = 0; i < 100; i++)
    {
        out << b[i] << endl;
    }
    out.close();

    // now we apply algorithm for gauss shiedel method//

    for (int i = 0; i < 100; i++)
    {
        x[i] = 0;
    }

    k = 1;
    del = 0.1;
    while (k <= 100 && del >= .0001)
    {
        for (int i = 0; i < 100; i++)
        {
            double sum = 0;
            for (int j = 0; j < 100; j++)
            {
                if (j != i)
                    sum += a[i][j] * x[j];
            }
            x[i] = (b[i] - sum) / a[i][i];
        }
        del = 0;
        for (int i = 0; i < 100; i++)
        {
            double sum=0;
            for (int j = 0; j < 100; j++)
            {
                sum += a[i][j] * x[j];
            }

            r[i] = b[i] - sum;
            del = del + r[i] * r[i];
        }

        del = sqrt(del);
        k = k + 1;
    }

    // printing final x values

    out.open("output_x.txt");
    for (int i = 0; i < 100; i++)
    {
        out << x[i] << endl;
    }

    out.close();

    return 0;
}