// power method to find Dominant eigen value//

#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

int main()
{
    ifstream in;
    int n, i, j, k, pos;
    n = 4;
    float a[n][n], b[n], x1[n], x2[n], sum, tol, x1norm, x2norm, xp, xq;
    // taking input to given matrix
    in.open("inputa.txt");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            in >> a[i][j];
        }
    }
    in.close();
    // initial guess for eigen vector
    in.open("input_initialguess.txt");
    for (i = 0; i < n; i++)
    {
        in >> x1[i];
    }
    in.close();
    // finding norm of element of x1 and scaling the x1

    x1norm = fabs(x1[0]);
    pos = 0;
    for (i = 0; i < n; i++)
    {
        if (x1norm < fabs(x1[i]))
        {
            x1norm = fabs(x1[i]);
            pos = i;
        }
    }
    xp = x1[pos];

    for (i = 0; i < n; i++)
    {
        x1[i] = x1[i] / xp;
    }
    k = 1;
    while (k < 100)
    {
        for (i = 0; i < n; i++)
        {
            sum = 0;
            for (j = 0; j < n; j++)
            {
                sum = sum + a[i][j] * x1[j];
            }
            x2[i] = sum;
        }

        x2norm = fabs(x2[0]);
        pos = 0;

        for (i = 0; i < n; i++)
        {
            if (x2norm < fabs(x2[i]))
            {
                x2norm = fabs(x2[i]);
                pos = i;
            }
        }
        xq = x2[pos];

        for (i = 0; i < n; i++)
        {
            x2[i] = x2[i] / xq;
        }
        tol = 0;
        for (i = 0; i < n; i++)
        {
            tol = tol + pow((x2[i] - x1[i]), 2);
        }
        tol = sqrt(tol);
        if (tol < 0.000001)
        {
            cout << "Dominant  eigen value of given matrix is: " << xq << endl;
            cout << "Eigen vector corresponding is :" << endl;
            for (i = 0; i < n; i++)
            {
                cout << x2[i] << endl;
            }
            break;
        }

        for (i = 0; i < n; i++)
        {
            sum = 0;
            for (j = 0; j < n; j++)
            {
                sum = sum + a[i][j] * x2[j];
            }
            x1[i] = sum;
        }

        x1norm = fabs(x1[0]);
        pos = 0;
        for (i = 0; i < n; i++)
        {
            if (x1norm < fabs(x1[i]))
            {
                x1norm = fabs(x1[i]);
                pos = i;
            }
        }
        xp = x1[pos];

        for (i = 0; i < n; i++)
        {
            x1[i] = x1[i] / xp;
        }
        k++;
    }
    cout<<"No of iteration: "<<k<<endl;
    return 0;
}
