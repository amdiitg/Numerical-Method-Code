// shifted inverse method to find minnimum eugen values//
#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;
int main()
{
    ifstream in;
    int i, j, k, n, pos, itr;
    n = 4;
    double a[n][n], l[n][n], u[n][n], y[n], x[n], b[n], I[n][n], q, sum, x1[n], x2[n], x1norm, x2norm, xp, xq, error, mineig;
    double c;
    in.open("inputa.txt");
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            in >> a[i][j];
        }
    }
    in.close();
    // identity matrix
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j)
                I[i][j] = 1;
            else
                I[i][j] = 0;
        }
    }
    // for A-qI
    q = 0; //q=0 for minimum eigen value
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            a[i][j] = a[i][j] - q * I[i][j];
        }
    }
    // initial guess eigen vector
    in.open("input_initialguess.txt");
    for (i = 0; i < n; i++)
    {
        in >> x1[i];
    }
    in.close();
    // finding Land U to solve Ax=b

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (i == j)
                l[i][j] = 1;
            else
                l[i][j] = 0;
        }
    }

    for (k = 0; k < n - 1; k++)
    {
        for (i = k + 1; i < n; i++)
        {
            c = a[i][k] / a[k][k];
            l[i][k] = c;
            for (j = 0; j < n; j++)
            {
                a[i][j] = a[i][j] - c * a[k][j];
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            u[i][j] = a[i][j];
        }
    }

    x1norm = abs(x1[0]);
    pos = 0;
    for (i = 0; i < n; i++)
    {
        if (x1norm < abs(x1[i]))
        {
            x1norm = abs(x1[i]);
            pos = i;
        }
    }
    xp = x1[pos];
    for (i = 0; i < n; i++)
    {
        x1[i] = x1[i] / xp;
    }

    itr = 1;
    while (itr < 10000)
    {

        for (i = 0; i < n; i++)
        {
            b[i] = x1[i];
        }
        // now solve Ly=b and the Ux=y to find x
        // first solve Ly=b by forward substitution//

        y[0] = b[0];
        for (i = 1; i < n; i++)
        {
            sum = 0;
            for (j = 0; j < i; j++)
            {
                sum = sum + l[i][j] * y[j];
            }
            y[i] = b[i] - sum;
        }

        // now solve Ux=y by backward substitution//
        x[n - 1] = y[n - 1] / u[n - 1][n - 1];
        for (i = n - 2; i >= 0; i--)
        {
            sum = 0;
            for (j = i + 1; j < n; j++)
            {
                sum = sum + u[i][j] * x[j];
            }
            x[i] = (y[i] - sum) / u[i][i];
        }

        for (i = 0; i < n; i++)
        {
            x2[i] = x[i];
        }

        x2norm = abs(x2[0]);
        pos = 0;

        for (i = 0; i < n; i++)
        {
            if (x2norm < abs(x2[i]))
            {
                x2norm = abs(x2[i]);
                pos = i;
            }
        }
        xq = x2[pos];
        for (i = 0; i < n; i++)
        {
            x2[i] = x2[i] / xq;
        }

        error = abs(x1[0] - x2[0]);
        for (i = 0; i < n; i++)
        {
            if (error < abs(x1[i] - x2[i]))

            {
                error = abs(x1[i] - x2[i]);
            }
        }

        if (error < 0.000001)
        {
            mineig = q+(1 / x2norm);
            cout << "Minimum eigen value is: " << mineig << endl;
            break;
        }

        for (i = 0; i < n; i++)
        {
            x1[i] = x2[i];
        }

        itr++;
    }

    cout << "No of iteration is :" << itr << endl;

    return 0;
}